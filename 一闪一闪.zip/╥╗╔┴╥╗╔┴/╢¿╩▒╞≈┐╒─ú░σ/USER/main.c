#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "sys.h"
#include "tim.h"
#include "bee.h"
int main(void)
{
	delay_init(168);
	LED_Init();
	TIM4_Init(7500,8400);//MAX:65535   8400 0000/8400(Ԥ��Ƶ��=10k 10k/5000����װ��ֵ��=2HZ T=0.5s
	Bee_Init();
	//TIM3_Init(38,8400);
	
	while(1)
	{
	}
}
